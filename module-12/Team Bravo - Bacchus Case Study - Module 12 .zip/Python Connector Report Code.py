import mysql.connector
from mysql.connector import errorcode


config = {"user": "root", "password": "12qwaszx!@QWASZX",
          "host": "127.0.0.1", "database": "bacchuswinery",
          "raise_on_warnings": True}


db = None

try:
    db = mysql.connector.connect(**config)
    cursor = db.cursor()
    query1 = '''SELECT YEAR(sh.shipment_actual_delivery_date),
            MONTH(sh.shipment_actual_delivery_date), su.supplier_name, COUNT(*)
            FROM shipments as sh
            JOIN suppliers as su ON sh.supplier_id = su.supplier_id
            WHERE sh.shipment_actual_delivery_date > sh.shipment_expected_delivery_date
            GROUP BY su.supplier_name, YEAR(sh.shipment_actual_delivery_date), MONTH(sh.shipment_actual_delivery_date)
            ORDER BY YEAR(sh.shipment_actual_delivery_date), MONTH(sh.shipment_actual_delivery_date)'''
    cursor.execute(query1)
    shipments = cursor.fetchall()
    print("---REPORT 1---\n")
    for shipment in shipments:
        print("Year: {}\nMonth: {}\nSupplier Name: {}\nLate_Deliveries: {}\n".format(shipment[0], shipment[1], shipment[2], shipment[3]))

    query2 = '''
                SELECT w.wine_type, COUNT(o.wine_id), group_concat(distinct d.distributor_name order by d.distributor_name separator ', ')
                FROM wines as w
                LEFT JOIN orders as o ON w.wine_id = o.wine_id
                JOIN distributors as d on o.distributor_id = d.distributor_id
                GROUP BY w.wine_type
                ORDER BY w.wine_type
            '''
    cursor.execute(query2)
    wines = cursor.fetchall()
    print("______________________________________________")
    print("---REPORT 2---\n")
    for wine in wines:
     print("Wine: {}\nTotal_Sold: {}\nDistributors: {}\n".format(wine[0], wine[1], wine[2]))

    # query3 = '''
    #         SELECT h.quarter_id, concat(e.employee_first, ' ', e.employee_last) as employee_name, h.hours_amount
    #         from hours as h
    #         JOIN employee as e on e.employee_id = h.employee_id
    #         '''
    # cursor.execute(query3)
    # employees = cursor.fetchall()
    # print("______________________________________________")
    # print("---REPORT 3---\n")
    # for employee in employees:
    #     print("Quarter: {}\nEmployee Name: {}\nHours Worked: {}\n".format(employee[0], employee[1], employee[2]))

    query3 =   '''
        SELECT concat(e.employee_first, ' ', e.employee_last) as employee_name, SUM(h.hours_amount) 
        from hours as h
        JOIN employee as e on e.employee_id = h.employee_id
        GROUP BY employee_name
        '''
    cursor.execute(query3)
    employees = cursor.fetchall()
    print("______________________________________________")
    print("---REPORT 3---\n")
    for employee in employees:
        print("Employee Name: {}\nTotal Hours Worked: {}\n".format(employee[0], employee[1]))

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print(" The supplied username or password are invalid")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("The specified database does not exist")
    else:
        print(err)
finally:
    if db:
        db.close()





