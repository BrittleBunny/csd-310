-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (x86_64)
--
-- Host: localhost    Database: bacchuswinery
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `distributors`
--

DROP TABLE IF EXISTS `distributors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `distributors` (
  `distributor_id` int NOT NULL,
  `distributor_name` varchar(45) NOT NULL,
  `distributor_sales` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distributors`
--

LOCK TABLES `distributors` WRITE;
/*!40000 ALTER TABLE `distributors` DISABLE KEYS */;
INSERT INTO `distributors` VALUES (1,'Specs',1123),(2,'Total Wine',1049),(3,'Wine World',978),(4,'Corner Spirits',546),(5,'Cigar House',432),(6,'Main Street Spirits',786);
/*!40000 ALTER TABLE `distributors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` int NOT NULL,
  `employee_first` varchar(45) NOT NULL,
  `employee_last` varchar(45) NOT NULL,
  `employee_department` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Stan','Bacchus','Owner'),(2,'Davis','Bacchus','Owner'),(3,'Janet','Collins','Finance'),(4,'Roz','Murphy','Marketing'),(5,'Bob','Ulrich','Marketing'),(6,'Henry','Doyle','Production'),(7,'Maria','Costanza','Distribution'),(8,'John','Davis','Production'),(9,'Ralph','Brown','Production'),(10,'Danny','Green','Production'),(11,'James','Jones','Production'),(12,'Raul','Gomez','Production'),(13,'Paul','Johnson','Production'),(14,'Chris','Tyler','Production'),(15,'Jaime','Reyez','Production'),(16,'Roddy','White','Production'),(17,'Darwin','Black','Production'),(18,'Esteban','Perez','Production'),(19,'Franco','Solis','Production'),(20,'Katie','Hart','Production'),(21,'Jeff','Simpson','Production'),(22,'Anna','Jones','Production'),(23,'Allen','Woodhead','Production'),(24,'Keith','Lawrence','Production'),(25,'Joseph','Hall','Production'),(26,'Gil','Brady','Production'),(27,'Scott','Parks','Production');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hours`
--

DROP TABLE IF EXISTS `hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hours` (
  `hours_amount` int NOT NULL,
  `quarter_id` int NOT NULL,
  `employee_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hours`
--

LOCK TABLES `hours` WRITE;
/*!40000 ALTER TABLE `hours` DISABLE KEYS */;
INSERT INTO `hours` VALUES (260,1,1),(360,2,1),(260,3,1),(360,4,1),(283,1,2),(383,2,2),(283,3,2),(383,4,2),(260,1,3),(360,2,3),(260,3,3),(360,4,3),(227,1,4),(327,2,4),(227,3,4),(327,4,4),(220,1,5),(320,2,5),(220,3,5),(320,4,5),(198,1,6),(230,2,6),(198,3,6),(230,4,6),(220,1,7),(320,2,7),(220,3,7),(320,4,7),(224,1,8),(324,2,8),(224,3,8),(324,4,8),(201,1,9),(301,2,9),(201,3,9),(301,4,9),(264,1,10),(344,2,10),(264,3,10),(344,4,10),(220,1,11),(320,2,11),(220,3,11),(320,4,11),(195,1,12),(295,2,12),(195,3,12),(295,4,12),(180,1,13),(280,2,13),(180,3,13),(280,4,13),(220,1,14),(320,2,14),(220,3,14),(320,4,14),(201,1,15),(301,2,15),(201,3,15),(301,4,15),(295,1,16),(395,2,16),(295,3,16),(395,4,16),(220,1,17),(320,2,17),(220,3,17),(320,4,17),(230,1,18),(330,2,18),(230,3,18),(330,4,18),(227,1,19),(327,2,19),(227,3,19),(327,4,19),(280,1,20),(280,2,20),(280,3,20),(280,4,20),(220,1,21),(320,2,21),(220,3,21),(320,4,21),(164,1,22),(244,2,22),(164,3,22),(244,4,22),(183,1,23),(283,2,23),(183,3,23),(283,4,23),(227,1,24),(327,2,24),(227,3,24),(327,4,24),(230,1,25),(330,2,25),(230,3,25),(330,4,25),(224,1,26),(324,2,26),(224,3,26),(324,4,26),(224,1,27),(324,2,27),(224,3,27),(324,4,27);
/*!40000 ALTER TABLE `hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `order_placement_date` datetime NOT NULL,
  `order_delivery_date` datetime NOT NULL,
  `order_amount` int NOT NULL,
  `distributor_id` int NOT NULL,
  `wine_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (101,'2024-01-01 00:00:00','2024-01-08 00:00:00',100,1,1),(102,'2024-01-01 00:00:00','2024-01-08 00:00:00',150,2,1),(103,'2024-01-01 00:00:00','2024-01-09 00:00:00',100,3,1),(104,'2024-01-01 00:00:00','2024-01-07 00:00:00',50,4,1),(105,'2024-02-25 00:00:00','2024-03-01 00:00:00',200,1,1),(106,'2024-03-01 00:00:00','2024-03-09 00:00:00',100,2,1),(107,'2024-03-03 00:00:00','2024-03-11 00:00:00',100,3,1),(108,'2024-03-15 00:00:00','2024-03-23 00:00:00',100,1,1),(109,'2024-03-30 00:00:00','2024-04-06 00:00:00',50,4,1),(110,'2024-03-30 00:00:00','2024-04-08 00:00:00',150,2,1),(201,'2024-01-01 00:00:00','2024-01-08 00:00:00',50,1,2),(202,'2024-01-01 00:00:00','2024-01-08 00:00:00',50,2,2),(203,'2024-02-01 00:00:00','2024-02-08 00:00:00',50,1,2),(204,'2024-02-01 00:00:00','2024-02-08 00:00:00',50,2,2),(205,'2024-03-01 00:00:00','2024-03-08 00:00:00',50,1,2),(206,'2024-03-01 00:00:00','2024-03-08 00:00:00',50,2,2),(301,'2024-01-01 00:00:00','2024-01-08 00:00:00',100,1,3),(302,'2024-01-01 00:00:00','2024-01-08 00:00:00',150,2,3),(303,'2024-01-01 00:00:00','2024-01-09 00:00:00',100,3,3),(304,'2024-01-01 00:00:00','2024-01-07 00:00:00',50,4,3),(305,'2024-02-25 00:00:00','2024-03-01 00:00:00',150,1,3),(306,'2024-03-01 00:00:00','2024-03-09 00:00:00',100,2,3),(307,'2024-03-03 00:00:00','2024-03-11 00:00:00',100,3,3),(308,'2024-03-15 00:00:00','2024-03-23 00:00:00',100,1,3),(309,'2024-03-30 00:00:00','2024-04-06 00:00:00',50,4,3),(310,'2024-03-30 00:00:00','2024-04-08 00:00:00',100,2,3),(401,'2024-01-01 00:00:00','2024-01-08 00:00:00',100,1,4),(402,'2024-01-01 00:00:00','2024-01-08 00:00:00',150,2,4),(403,'2024-01-01 00:00:00','2024-01-09 00:00:00',100,3,4),(404,'2024-01-01 00:00:00','2024-01-07 00:00:00',50,4,4),(405,'2024-02-25 00:00:00','2024-03-01 00:00:00',150,1,4),(406,'2024-03-01 00:00:00','2024-03-09 00:00:00',100,2,4),(407,'2024-03-03 00:00:00','2024-03-11 00:00:00',100,3,4),(408,'2024-03-15 00:00:00','2024-03-23 00:00:00',100,1,4),(409,'2024-03-30 00:00:00','2024-04-06 00:00:00',50,4,4),(410,'2024-03-30 00:00:00','2024-04-08 00:00:00',150,2,4),(501,'2024-01-01 00:00:00','2024-01-08 00:00:00',100,1,5),(502,'2024-01-01 00:00:00','2024-01-08 00:00:00',150,2,5),(503,'2024-01-01 00:00:00','2024-01-09 00:00:00',100,3,5),(504,'2024-01-01 00:00:00','2024-01-07 00:00:00',50,4,5),(505,'2024-02-25 00:00:00','2024-03-01 00:00:00',200,1,5),(506,'2024-03-01 00:00:00','2024-03-09 00:00:00',100,2,5),(507,'2024-03-03 00:00:00','2024-03-11 00:00:00',100,3,5),(508,'2024-03-15 00:00:00','2024-03-23 00:00:00',100,1,5),(509,'2024-03-30 00:00:00','2024-04-06 00:00:00',50,4,5),(510,'2024-03-30 00:00:00','2024-04-08 00:00:00',150,2,5),(601,'2024-01-01 00:00:00','2024-01-08 00:00:00',50,1,6),(602,'2024-01-01 00:00:00','2024-01-08 00:00:00',50,2,6),(603,'2024-02-01 00:00:00','2024-02-08 00:00:00',50,1,6),(604,'2024-02-01 00:00:00','2024-02-08 00:00:00',50,2,6),(605,'2024-03-01 00:00:00','2024-03-08 00:00:00',50,1,6),(606,'2024-03-01 00:00:00','2024-03-08 00:00:00',50,2,6);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quarter`
--

DROP TABLE IF EXISTS `quarter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quarter` (
  `quarter_id` int NOT NULL,
  `quarter_start_date` datetime NOT NULL,
  `quarter_end_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quarter`
--

LOCK TABLES `quarter` WRITE;
/*!40000 ALTER TABLE `quarter` DISABLE KEYS */;
INSERT INTO `quarter` VALUES (1,'2024-01-01 00:00:00','2024-03-31 00:00:00'),(2,'2024-04-01 00:00:00','2024-06-30 00:00:00'),(3,'2024-07-01 00:00:00','2024-09-30 00:00:00'),(4,'2024-10-01 00:00:00','2024-12-31 00:00:00');
/*!40000 ALTER TABLE `quarter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipments`
--

DROP TABLE IF EXISTS `shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipments` (
  `shipment_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `shipment_order_placement_date` datetime NOT NULL,
  `shipment_expected_delivery_date` datetime NOT NULL,
  `shipment_actual_delivery_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipments`
--

LOCK TABLES `shipments` WRITE;
/*!40000 ALTER TABLE `shipments` DISABLE KEYS */;
INSERT INTO `shipments` VALUES (11,1,'2024-01-01 00:00:00','2024-01-18 00:00:00','2024-01-18 00:00:00'),(12,2,'2024-01-01 00:00:00','2024-01-15 00:00:00','2024-01-19 00:00:00'),(13,3,'2024-01-01 00:00:00','2024-01-23 00:00:00','2024-01-22 00:00:00'),(101,1,'2024-02-01 00:00:00','2024-02-18 00:00:00','2024-02-18 00:00:00'),(102,2,'2024-02-01 00:00:00','2024-02-15 00:00:00','2024-02-15 00:00:00'),(103,3,'2024-02-01 00:00:00','2024-02-23 00:00:00','2024-02-23 00:00:00'),(111,1,'2024-03-01 00:00:00','2024-03-18 00:00:00','2024-03-15 00:00:00'),(112,2,'2024-03-01 00:00:00','2024-03-15 00:00:00','2024-03-14 00:00:00'),(113,3,'2024-03-01 00:00:00','2024-03-23 00:00:00','2024-03-23 00:00:00'),(121,1,'2024-04-01 00:00:00','2024-04-18 00:00:00','2024-04-15 00:00:00'),(122,2,'2024-04-01 00:00:00','2024-04-15 00:00:00','2024-04-15 00:00:00'),(123,3,'2024-04-01 00:00:00','2024-04-23 00:00:00','2024-04-23 00:00:00'),(201,1,'2024-05-01 00:00:00','2024-05-18 00:00:00','2024-05-20 00:00:00'),(202,2,'2024-05-01 00:00:00','2024-05-15 00:00:00','2024-05-15 00:00:00'),(203,3,'2024-05-01 00:00:00','2024-05-23 00:00:00','2024-05-23 00:00:00'),(301,1,'2024-06-01 00:00:00','2024-06-18 00:00:00','2024-06-18 00:00:00'),(302,2,'2024-06-01 00:00:00','2024-06-15 00:00:00','2024-06-15 00:00:00'),(303,3,'2024-06-01 00:00:00','2024-06-23 00:00:00','2024-06-25 00:00:00'),(401,1,'2024-07-01 00:00:00','2024-07-18 00:00:00','2024-07-18 00:00:00'),(402,2,'2024-07-01 00:00:00','2024-07-15 00:00:00','2024-07-15 00:00:00'),(403,3,'2024-07-01 00:00:00','2024-07-23 00:00:00','2024-07-23 00:00:00'),(501,1,'2024-08-01 00:00:00','2024-08-18 00:00:00','2024-08-18 00:00:00'),(502,2,'2024-08-01 00:00:00','2024-08-15 00:00:00','2024-08-15 00:00:00'),(503,3,'2024-08-01 00:00:00','2024-08-23 00:00:00','2024-08-23 00:00:00'),(601,1,'2024-09-01 00:00:00','2024-09-18 00:00:00','2024-09-16 00:00:00'),(602,2,'2024-09-01 00:00:00','2024-09-15 00:00:00','2024-09-15 00:00:00'),(603,3,'2024-09-01 00:00:00','2024-09-23 00:00:00','2024-09-23 00:00:00'),(701,1,'2024-10-01 00:00:00','2024-10-18 00:00:00','2024-10-18 00:00:00'),(702,2,'2024-10-01 00:00:00','2024-10-15 00:00:00','2024-10-15 00:00:00'),(703,3,'2024-10-01 00:00:00','2024-10-23 00:00:00','2024-10-23 00:00:00'),(801,1,'2024-11-01 00:00:00','2024-11-18 00:00:00','2024-11-18 00:00:00'),(802,2,'2024-11-01 00:00:00','2024-11-15 00:00:00','2024-11-15 00:00:00'),(803,3,'2024-11-01 00:00:00','2024-11-23 00:00:00','2024-11-23 00:00:00'),(901,1,'2024-12-01 00:00:00','2024-12-18 00:00:00','2024-12-20 00:00:00'),(902,2,'2024-12-01 00:00:00','2024-12-15 00:00:00','2024-12-16 00:00:00'),(903,3,'2024-12-01 00:00:00','2024-12-23 00:00:00','2024-12-24 00:00:00');
/*!40000 ALTER TABLE `shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `supplier_id` int NOT NULL,
  `supplier_name` varchar(45) NOT NULL,
  `supplier_product` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'Benjamin Bottling','bottles, cork'),(2,'The Shipping Co','boxes, labels'),(3,'The Kemist','vats, tubing');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wines`
--

DROP TABLE IF EXISTS `wines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wines` (
  `wine_id` int NOT NULL,
  `wine_type` varchar(45) NOT NULL,
  `wine_stock` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wines`
--

LOCK TABLES `wines` WRITE;
/*!40000 ALTER TABLE `wines` DISABLE KEYS */;
INSERT INTO `wines` VALUES (1,'Chardonnay',1250),(2,'Pinot Noir',500),(3,'Chablis',1000),(4,'Merlot',1100),(5,'Cabernet',1150),(6,'Champagne',400);
/*!40000 ALTER TABLE `wines` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-05 19:15:38
